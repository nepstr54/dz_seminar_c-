﻿//Задача 4: Напишите программу, которая принимает на вход три числа и выдаёт максимальное из этих чисел.
//2, 3, 7 -> 7
//44 5 78 -> 78
//22 3 9 -> 22
//by Nepstr




Console.WriteLine("Введите первое число:");
int numa = Convert.ToInt32(Console.ReadLine());

Console.WriteLine("Введите второе число:");
int numb = Convert.ToInt32(Console.ReadLine());

Console.WriteLine("Введите третье число:");
int numc = Convert.ToInt32(Console.ReadLine());


if (numa > numb && numa > numc)
{
    Console.WriteLine($"Число: {numa} больше");
}

else if (numb > numa && numb > numc)
{
    Console.WriteLine($"Число: {numb} больше");
}

else if (numc > numa && numc > numb)
{
    Console.WriteLine($"Число: {numc} больше");
}
