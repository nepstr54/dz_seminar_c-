﻿//Задача 6: Напишите программу, которая на вход принимает число и выдаёт, является ли число чётным (делится ли оно на два без остатка).
//4->да
//- 3->нет
//7->нет
//by Nepstr

Console.WriteLine("Введите  число:");
int numa = Convert.ToInt32(Console.ReadLine());

if ((numa % 2 == 0))
{
    Console.WriteLine("четное");
}

else
{
    Console.WriteLine("Нечетное");
}
